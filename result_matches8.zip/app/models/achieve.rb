class Achieve < ApplicationRecord
  has_many :gamer_achieves
end
