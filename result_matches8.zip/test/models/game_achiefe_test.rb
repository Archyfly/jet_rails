require 'test_helper'

class GameAchiefeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
