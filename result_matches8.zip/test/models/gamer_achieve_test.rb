require 'test_helper'

class GamerAchieveTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
