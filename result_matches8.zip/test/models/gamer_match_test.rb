require 'test_helper'

class GamerMatchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
